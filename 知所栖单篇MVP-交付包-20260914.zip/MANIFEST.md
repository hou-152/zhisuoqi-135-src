# MANIFEST · 快照说明

## 1. 这是什么

- **交付物**：知所栖「内参单篇 MVP」当前版本的只读快照（代码与产物 ＋ 已有证据）。
- **不是**：不是可独立启动的工程（缺 `knowledge/` 数据源与凭证），不是发布物，不是学习效果报告。
- **打包时间**：2026-09-14（打包脚本只做 `cp` 与 `zip`，不改任何源文件、不跑模型、不跑测试）。

## 2. 基线提交

| 项 | 值 |
|---|---|
| 仓库根 | `/Users/housibo/Documents/知乎黑客松` |
| 分支 | `feat/neican-260912-daily` |
| **基线提交（HEAD）** | **`c7da646`** — `docs: 记录本轮收工同步（feat f8b5b2d → main a364f54；GitHub main 与线上公网站同版 999 概念）` |
| 被测版本所在提交 | **`f8b5b2d`** — `feat(neican): 260913 期内参（8 篇三产物 + 81 概念并入地图 918→999）+ 内参栏改多期「日报集合」（月历 → 分类 → 策展）`（2026-09-14 05:30:22 +0800） |
| 打包时工作区 | **干净**（`git status --porcelain` = **0 项**） |
| 快照口径 | 包内文件 = `c7da646` 的工作树内容；交付字节以本文件 §4 的 sha256 为准 |

## 3. 参与被测版本的未提交改动（逐个文件 ＋ 一行说明）

**先说结论，因为事实在打包过程中变了：**

- 本交付轮**勘定开始时**（约 05:2x），HEAD = `aa9ac38`，工作区有 **263 项未提交改动**——本试点（读中即时费曼、判据映射、拆分后的两种费曼、诊断证据）当时**全部处于未提交状态**。
- 打包**开始前**，**并行会话**把这 263 项提交为 **`f8b5b2d`**（05:30:22），随后提交 `c7da646`（仅两处文档：`SOURCE_OF_TRUTH.md`、`docs/工作日志-知所栖135.md`）。
- 因此**打包这一刻，「参与被测版本的未提交改动 = 0 项」**。上一条的表格改为登记**每个入包文件的最后改动提交**，作用等价：读者能逐文件确认「它属于哪一次提交、被谁带进当前版本」。
- 打包期间**并行会话一直在动**（重建了 `prototype/知所栖-壳.html`，05:30；重建输出与 05:19 那版**逐字节一致**，sha256 相同）。本包不清理、不回退、不覆盖任何并行改动。

### 3.1 `01-当前版本/`（15 个文件）

| # | 文件（包内路径） | 最后改动 | 一行说明 |
|---|---|---|---|
| 1 | `prototype/知所栖-壳.html` | `f8b5b2d` | 试点页面产物（单文件壳，2.53 MB）。**构建产物**，含 999 概念 payload、内参两期、六章学习材料、试点 `teachingMap`（C1–C4 ＋ 五档规则） |
| 2 | `scripts/shell.template.html` | `f8b5b2d` | 页面模板，壳的唯一源码：页面状态机、路径视图、独立学习空间、内参日报集合、**阅读中的即时费曼**（含两种费曼的拆分） |
| 3 | `scripts/build-shell.mjs` | `f8b5b2d` | 构建壳产物：装 `DATA.neican.issues` 与六章材料，写 `prototype/知所栖-壳.html`。**需要包外的 `knowledge/` 输入** |
| 4 | `scripts/build-neican.mjs` | `f8b5b2d` | 逐期生成内参页面数据；把 `evidence/feynman-teaching-map/<slug>.json` 装成 payload 的 `teachingMap`（含 `gradingRules` 五档规则） |
| 5 | `evidence/feynman-teaching-map/agent-skills-api.json` | `f8b5b2d` | 试点篇的判据与材料映射：4 条判据 ×（判据原文 ＋ 误解 ＋ 教学动作 ＋ 材料指针 ＋ 五档规则），`criteriaVersion v3-20260914`，绑定源文件 sha256 |
| 6 | `scripts/map-feynman-gaps.mjs` | `f8b5b2d` | 确定性映射器（**不调模型、不联网**）：`--check` 校验映射表／`--answers` 跑 4 组固定答案／`--diagnose` 诊断自由复述 |
| 7 | `scripts/serve-lib.mjs` | `f8b5b2d` | 本地服务本体：静态服务 ＋ `/api/llm` ＋ `/api/learn` ＋ `/api/search`；凭证加载与**进程内每分钟限流** |
| 8 | `scripts/lib/llm.mjs` | `f8b5b2d` | OpenAI 兼容传输层（发一次 chat completion；不负责重试／缓存／降级，策略归调用方） |
| 9 | `scripts/serve-135.mjs` | `b95ad9f`（09-12） | 命令行启动壳（端口 5180）。**为「最短启动命令能存在」而入包**，理由见 §6 |
| 10 | `scripts/test-neican-inline-feynman.mjs` | `f8b5b2d` | 即时费曼页面闭环验收脚本（**固定响应**；脚本自述「不证明模型判定质量」） |
| 11 | `scripts/test-learn-agent-loop.mjs` | `f8b5b2d` | 独立学习空间状态门验收：一题一判／费曼门／未过不解锁／改复述清状态／草稿落盘／正文流一页 |
| 12 | `scripts/test-learn-api.mjs` | `f8b5b2d` | `/api/learn` 接口验收 |
| 13 | `evidence/agent-loop-260913/authored.json` | `f8b5b2d` | 六章正文流撰写稿：导语／过渡句／关系句／`inlineFeynman`／`nextBridge`，每条带逐字原文（构建时比对不到即失败） |
| 14 | `evidence/agent-loop-260913/chapters.json` | `f8b5b2d` | 六章装配产物（页面消费的那一份），363 项材料体检的对象 |
| 15 | `scripts/build-learning-materials.mjs` | `f8b5b2d` | 六章装配器（**不调模型**；ID／类型／主案例／依据逐字对不上即失败退出） |

### 3.2 `02-证据/`（19 个文件，全部复用、未重跑、未改写）

| # | 文件（包内路径） | 最后改动 | 一行说明 |
|---|---|---|---|
| 1 | `feynman-teaching-map/inline-feedback-20260913203338.json` | `f8b5b2d` | **D 层连续反馈**：3 轮（D1 C3 讲错 → D2 **负对照·错误未纠正** → D3 C3 讲对）＋ 不解锁探针（`keys:0 marks:0`）＋ 决策题入口探针；21 条断言；3 次真实调用 |
| 2 | `feynman-teaching-map/inline-feedback-20260913211441.json` | `f8b5b2d` | 同脚本后续复跑 #1（同样 3 轮 ＋ 21 条断言；本份 `callLog` 为空） |
| 3 | `feynman-teaching-map/inline-feedback-20260913211701.json` | `f8b5b2d` | 同脚本后续复跑 #2（同上） |
| 4 | `feynman-teaching-map/inline-feedback-20260913211814.json` | `f8b5b2d` | 同脚本后续复跑 #3（同上） |
| 5 | `feynman-teaching-map/real-diagnosis-20260913203201.json` | `f8b5b2d` | C 层真实诊断第 1 次：11 组答案，v3 判据 |
| 6 | `feynman-teaching-map/real-diagnosis-20260913203426.json` | `f8b5b2d` | C 层真实诊断第 2 次（同条件复测） |
| 7 | `feynman-teaching-map/real-diagnosis-20260913211128.json` | `f8b5b2d` | **最新一次诊断**：逐组保留 `expected`（脚本里独立写的预期）／`observed`（实测）／`diff`（多判·漏判），**判定失误原样保留** |
| 8 | `issue2-复核-20260914.md` | `f8b5b2d` | Issue 2 复核文件：命令与输出逐字粘贴，A/B/C/D 分层结论（A PASS · B PASS · C UNSTABLE · D PASS）与未执行项 |
| 9 | `feynman-split-20260914/logs/BASE-browser.txt` | `f8b5b2d` | 「两种费曼拆分」动手**前**的基线回执 |
| 10 | `feynman-split-20260914/logs/FINAL-offline.txt` | `f8b5b2d` | 最终回归·离线部分（材料体检 **363 项**、判据映射 **117 项**） |
| 11 | `feynman-split-20260914/logs/FINAL-browser-5180.txt` | `f8b5b2d` | 最终回归·浏览器侧（5180）回执 |
| 12 | `feynman-split-20260914/logs/FINAL-regression-all.txt` | `f8b5b2d` | 最终全量回归汇总 |
| 13 | `截图/60-即时费曼-入口与阅读梯度.png` | `f8b5b2d` | 桌面：入口与阅读梯度（真实页面状态，非示意图） |
| 14 | `截图/61-即时费曼-单处重点补讲.png` | `f8b5b2d` | 桌面：只补一处重点 |
| 15 | `截图/62-即时费曼-讲全一轮.png` | `f8b5b2d` | 桌面：讲全一轮 |
| 16 | `截图/63-即时费曼-未判定与澄清.png` | `f8b5b2d` | 桌面：未判定与澄清（不伪造通过） |
| 17 | `截图/64-即时费曼-窄屏.png` | `f8b5b2d` | **窄屏**：同一闭环的窄屏形态 |
| 18 | `截图/70-即时费曼-真模型第一轮-C3讲错.png` | `f8b5b2d` | 真模型（D1）：C3 讲错 |
| 19 | `截图/71-即时费曼-真模型第三轮-C3讲对.png` | `f8b5b2d` | 真模型（D3）：C3 讲对 |

## 4. 入包文件 sha256（逐个）

### 包根

| 文件 | 字节 | sha256 |
|---|---:|---|
| `README.md` | 8865 | `a46f4bce6b49face9dab02e4a88113182dd49c496cbcc893ad04ebabae8e13f9` |

### 01-当前版本/

| 文件 | 字节 | sha256 |
|---|---:|---|
| `01-当前版本/evidence/agent-loop-260913/authored.json` | 47869 | `7dc25beff7bd7bb27ff40c3df17543b8c4c4167fb72aba90d7a1fab819860cde` |
| `01-当前版本/evidence/agent-loop-260913/chapters.json` | 112227 | `eca4944e029f97b3973d47eaa40ff17595cfc7888fa250571de9c2ca7ffe0479` |
| `01-当前版本/evidence/feynman-teaching-map/agent-skills-api.json` | 16557 | `176c751da7975a13f86405c93b34bf474da147c8043e7a22915c07de0dc32264` |
| `01-当前版本/prototype/知所栖-壳.html` | 2532066 | `27340af7fb233471dd2ce5c8164af85e923f233b090c3be4f3c32db00aea722e` |
| `01-当前版本/scripts/build-learning-materials.mjs` | 18409 | `1200c4e83493b3b49aa088e6b5b6d5647c81a61d65fdf8a8b3348d2ad27f7aee` |
| `01-当前版本/scripts/build-neican.mjs` | 26395 | `c87748e6c3787f995f817766bd7b917919ef1acbe645170007046e74c2b22014` |
| `01-当前版本/scripts/build-shell.mjs` | 12653 | `1dee6a123a61f8f936b91c2ab9e4da0e3cddc640e3cd1aebe1eb6d36d960d9d4` |
| `01-当前版本/scripts/lib/llm.mjs` | 1914 | `f170ce1269efcb6fa4c622610dfbc96918d71b927fda4b94e587edab8d5545eb` |
| `01-当前版本/scripts/map-feynman-gaps.mjs` | 8925 | `45e94c4a89d7a6fc3a29d1a02a9af00e5b57c2e3551d97f1b723438d0ecb5444` |
| `01-当前版本/scripts/serve-135.mjs` | 1113 | `e0377c810d277cd7185ebfdd4792e77e759d56255af1294e1725fce108d9133d` |
| `01-当前版本/scripts/serve-lib.mjs` | 26748 | `c07750eed74811c528d33b56b3859f90000fb2674250594c57d0773eaf7acba9` |
| `01-当前版本/scripts/shell.template.html` | 197326 | `097e557ec0601667b74d03c22518c8acb6ad8e1d5ef20d08a7e0c0315aed2f54` |
| `01-当前版本/scripts/test-learn-agent-loop.mjs` | 26338 | `70a75ba6b37ca411f2a377bc487b3d298226475e4a339745d4dbf580b25f0f0a` |
| `01-当前版本/scripts/test-learn-api.mjs` | 15709 | `1542ed700eac1459f21dfd58e0683373ed4754ff168c1253c8192a07aad1dac1` |
| `01-当前版本/scripts/test-neican-inline-feynman.mjs` | 30841 | `7dd87bee53eaacb614dd19c2326e65a1dc54424a40425994918beb2e0ad5c370` |

### 02-证据/

| 文件 | 字节 | sha256 |
|---|---:|---|
| `02-证据/feynman-split-20260914/logs/BASE-browser.txt` | 3940 | `e641bdb77d577de864a0b6487b56b26a29f1fdc52784b013861844ee49d4383b` |
| `02-证据/feynman-split-20260914/logs/FINAL-browser-5180.txt` | 19393 | `abb90d204ac5a51309f6008d37635addb39b8faefdd02ab291c9a3882cb532c2` |
| `02-证据/feynman-split-20260914/logs/FINAL-offline.txt` | 1009 | `71758cb64acdf8a2fd6aec8eda6d1629db5181a8d037246ddcc6dab97e93618a` |
| `02-证据/feynman-split-20260914/logs/FINAL-regression-all.txt` | 22425 | `4fc124ed5ea55320509a52cd450155e83dadd312aed0d98121f4586e3bc09dbd` |
| `02-证据/feynman-teaching-map/inline-feedback-20260913203338.json` | 23799 | `ce799ea6e70220906989fe40dc0fdfe3702e04b727766514398bfd65622ff04d` |
| `02-证据/feynman-teaching-map/inline-feedback-20260913211441.json` | 15325 | `433feb1c5e92ad1ea4171fcc6021cbd229a10a8db915e525739bc08cd6521422` |
| `02-证据/feynman-teaching-map/inline-feedback-20260913211701.json` | 14308 | `ed8f93ce059f69378e6e658d4d424577db1c87b5e2c0a93ecc40ecfa372375a7` |
| `02-证据/feynman-teaching-map/inline-feedback-20260913211814.json` | 16506 | `61be371707b17d1147a057369b9bd46e20bf9db1c635a47d197dce460083a57e` |
| `02-证据/feynman-teaching-map/real-diagnosis-20260913203201.json` | 28341 | `b08976f08627bafb8bc5ae5b452ece48983496ec6c63610a17c974331840a853` |
| `02-证据/feynman-teaching-map/real-diagnosis-20260913203426.json` | 27599 | `91299373ae985accf7450d9d839f55216cd86586b08775ec7b8c9ce7e3a09244` |
| `02-证据/feynman-teaching-map/real-diagnosis-20260913211128.json` | 44784 | `fee9d337e16a4e32cf44622a273d4c7f4232d49bb0a97a07868aa7d702ba0e46` |
| `02-证据/issue2-复核-20260914.md` | 27573 | `d17acc56a931d3cdf9d0dd9e6e315cc1b9b42ac5bd1256ae67cc6d311360c204` |
| `02-证据/截图/60-即时费曼-入口与阅读梯度.png` | 204503 | `2f2bbd926d22b2f3327724a6df3df19ad3c66e8b5e1e6b9bc760f00ad9b066b1` |
| `02-证据/截图/61-即时费曼-单处重点补讲.png` | 235046 | `6eb2df656917223e7433b59ead629b5a5810603bc8d143e5255d9e5d29c1a0e1` |
| `02-证据/截图/62-即时费曼-讲全一轮.png` | 207091 | `9de9bee1137668258bcd578697e88abbb7dfe6ca9efdc87a217f2688ed31d437` |
| `02-证据/截图/63-即时费曼-未判定与澄清.png` | 209125 | `0040ef0b0aa450eb06f7eafcecbf7ccffe87b5b3804af7753b854a2b9ae238e8` |
| `02-证据/截图/64-即时费曼-窄屏.png` | 293748 | `fc0c21f848972833b37fdd92b0bec20f78fae8d3f1d13b53d7a483e7ee2c7d21` |
| `02-证据/截图/70-即时费曼-真模型第一轮-C3讲错.png` | 253282 | `dd73c1b723549c8b76cfad893364e2581c7b0f80fa10d166cd670319e1b9e178` |
| `02-证据/截图/71-即时费曼-真模型第三轮-C3讲对.png` | 251704 | `4dcb321fb07dd7001e560fb47b6a5bd6f607897272588375df788d63b6f1ad9f` |

合计上表 **35** 个文件（`MANIFEST.md` 自身不自列，因而包内文件条目共 36 个）。

## 5. 与历史证据的快照差异声明（逐条，均为「证据早于当前代码」，未改写任何历史证据）

1. **`issue2-复核-20260914.md` §3 引用的截图 ≠ 包内截图**。文档写于 **04:37**，它列的是 04:35/04:36 那批截图（如 60 号 256,954 字节）；包内 `60–64` 是 **05:23 重拍**（60 号 204,503 字节）。**字节与大小都不同**，包内是重拍版。文档正文里的项数（如「111 项」「344 项」）对应 04:35 的代码，**最终回归是 117 项 / 363 项**（见 `FINAL-*.txt`）。
2. **`real-diagnosis-20260913203201/203426` ＋ `inline-feedback-20260913203338`（04:31–04:35）早于「两种费曼拆分」**。拆分动手前的基线是 `BASE-browser.txt`（**04:55**），最终回归是 `FINAL-regression-all.txt`（**05:21**）。这 3 份证据跑在拆分**之前**的页面上；判据版本一致（都是 `criteriaVersion v3-20260914`），但**不能声称跑在最终模板上**。
3. **`real-diagnosis-20260913211128` 与 3 份 `inline-feedback-20260913211441/211701/211814`（05:10–05:18）在基线之后、最终回归之前**，同样**早于 05:21 那次全量回归**。
4. **两份更早的诊断不在包内**：`real-diagnosis-20260913195225.json`、`real-diagnosis-20260913200053.json` 在打包前已被**并行会话**从工作区删除并随 `f8b5b2d` 提交删除。按交付口径**不复活、不改写**；如需引用，可用 `git show aa9ac38:<路径>` 取回。
5. **`criteriaVersion` 与代码当前一致**（映射文件、页面 payload、三份诊断与四份连续反馈都是 `v3-20260914`）；但 **C2 判据曾在负责人裁决后从 v2 改到 v3**，改动提交是 `aa9ac38`，因此**任何声称「C2 判定稳定性」的结论只能引用 v3 之后的记录**。
6. **`prototype/知所栖-壳.html` 是构建产物**：它在 05:30 被并行会话重建（与 05:19 版逐字节一致）。证据截图来自更早的构建，**页面模板此后（拆分、重建）有过改动**；本包不对截图与产物做「同一秒快照」的宣称，只承诺**每一份证据的运行时点**如上所述。
7. **未入包的生成器**：`02-证据/` 的 16 份 JSON/TXT 由 `scripts/walk-inline-feynman-real.mjs`、`scripts/diag-feynman-real.mjs`、`scripts/walk-learn-agent-loop.mjs`、`scripts/test-*.mjs` 产出；除 `test-neican-inline-feynman.mjs` / `test-learn-agent-loop.mjs` / `test-learn-api.mjs` 外，**其余生成器不在本包**（不在最少必要集，见 §6）。查看或复跑请回仓库。

## 6. 入包与未入包清单

**按原清单入包，未入包的项如实列出：**

| 清单项 | 状态 | 原因 |
|---|---|---|
| 项目根 `package.json` | **缺** | **项目本来就没有这个文件**（启动只需 Node，无 npm install）。不是遗漏 |
| `scripts/serve-135.mjs` | **额外入包** | 原清单未列，但 README §2 的最短启动命令就是它；不放则「启动命令」在包内不存在。**只加这一个文件，未另造服务** |
| `knowledge/概念地图-260913/`、`knowledge/内参-*/`、`content/`、`research/` 等大目录 | **不入包** | 交付边界：只放试点相关；且 `knowledge/` 是私有大目录。**后果已写进 README §2：包内无法重建页面** |
| `deploy/` 公网产物、`app/dist/` | 不入包 | 交付边界（禁止打包项） |
| 私有凭证目录、任何 `env` 凭证文件、密钥／令牌、`node_modules/` | 不入包 | 交付边界；已做敏感串扫描（见 §7） |
| `scripts/walk-inline-feynman-real.mjs`、`diag-feynman-real.mjs`、其余测试脚本 | 不入包 | 不在最少必要集；已在 §5-7 登记路径 |

## 7. 自查结果

1. **条目数**：`unzip -l` 实测 **48 个条目** = **36 个文件**（`README.md` ＋ `MANIFEST.md` ＋ `01-当前版本/` 15 ＋ `02-证据/` 19）＋ **12 个目录条目**。解压总大小与压缩包大小随 `MANIFEST.md` 自身长度有几十字节级浮动，**以本轮交付回执（发给负责人的消息，不在包内）实测数字为准**。文件名以 UTF-8 标志写入（非 ASCII 条目 46 个、缺标志 0 个），`ditto -x -k`（macOS 原生）与 Python `zipfile` 解出的名字均无乱码；逐文件 sha256 与 §4 表**全部一致**（0 处不匹配）。
2. **敏感串扫描**（对**解压后**的包内全部文件做二进制安全扫描；5 个串依次为：密钥前缀、凭证文件名词、访问密钥串、私有目录名、PEM 私钥头。**访问密钥串与 PEM 私钥头这两个字面串本节不复述**；密钥前缀无法在解释假阳性时避开，因为它就长在 `Task-Oriented` 这类英文词里。逐串原文写法与逐条命中位置见交付回执）：
   - **真实凭证形态（密钥前缀 ＋ 20 位以上密钥体）：0 处命中。**
   - 密钥前缀裸串：3 个文件命中，**全部是词内子串的假阳性**——「Ta·sk-·Oriented」「ri·sk-·averse」（在壳 payload 里）、`'ta·sk-·required'`（`serve-lib.mjs` 的报错码）。
   - 凭证路径名（凭证文件名词 / 私有目录名）：仅命中**引用该路径的源码注释与代码**（`serve-135.mjs`、`serve-lib.mjs`、`build-neican.mjs`、`test-learn-api.mjs`）＋ README §5 那一行（该行是交付要求本身：写明凭证只在本机）。**包内没有该目录、没有该文件、没有任何 key 值。** 源码按快照原样入包，**未为了扫描好看而改写代码**。
   - 访问密钥串、PEM 私钥头：**0 处命中**。
   - 结论：**无凭证材料泄漏**；命中项都是「说出凭证在哪」的文字，不是凭证本身。
3. **结构自检**：`README.md`、`MANIFEST.md` 在包根；`01-当前版本/`（15 个文件）、`02-证据/`（19 个文件）**均非空**。
4. **本轮未执行**：不跑真模型、不跑测试套件、不重建产物、不部署、不 push、不 commit、不清理工作区、不覆盖并行改动。
5. **定稿重打**：首次自查跑完后只改了**两处纯文字**（不动代码、不动证据）——README §2-4 与 §4-③-2 里对凭证位置的重复表述改成「见 §5」，并让本文件不再复述扫描用的字面串。改完**重新计算 sha256、重新打包、重新跑完上面 1–3 项**；§4 的哈希表与本节结论都是**定稿包**的实测值。
